NOVA GAME HUB - ANDROID APP PROJECT

This project wraps the supplied HTML demo in an Android WebView.

IMPORTANT:
- This is a demo. Access keys and seller settings are stored on the device only.
- It does NOT have a secure online database or real server-side key validation.
- The APK must be built by Android/Gradle. This workspace has no Android SDK installed, so no APK was compiled here.

EASIEST BUILD PATH:
1. Sign in to GitHub and create a NEW PRIVATE repository named NovaGameHub.
2. Upload all files and folders from this project to the repository root.
3. Open the repository's Actions tab.
4. Choose "Build Nova Game Hub APK" and press "Run workflow" (or push to main).
5. When it finishes, open the workflow run and download the "Nova-Game-Hub-APK" artifact.
6. Extract the downloaded ZIP on your Android phone and install app-debug.apk. Android may ask you to allow installs from that source.

For a production app, add secure admin login, a server/database, and server-side key validation before selling access.
